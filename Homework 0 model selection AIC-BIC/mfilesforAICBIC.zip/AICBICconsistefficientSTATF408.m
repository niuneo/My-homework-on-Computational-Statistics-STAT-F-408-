
nsimul = 1000;
samplesizes = [50 100 200 500 1500];
samplesizes = sort(samplesizes);
nss = length(samplesizes);
n = samplesizes(end);
x1 = rand(n,nsimul);
x2 = randn(n,nsimul)+5;
ZZ = randn(n,nsimul);
beta0 = 2;
beta1 = 3;
beta2 = 0;
stdev = 1.5;
YY = beta0+beta1*x1+beta2*x2+stdev*ZZ;
mumu = beta0+beta1*x1+beta2*x2;

% model 1: beta0
% model 2: beta0, beta1
% model 3: beta0, beta2
% model 4: beta0, beta1, beta2
models = {[1],[1 2],[1 3],[1 2 3]};
nmodels = length(models);
for m=1:nmodels, p(m) = length(models{m}); end
aicmodel = zeros(nsimul,nss);
bicmodel = zeros(nsimul,nss);
EffAIC = zeros(nsimul,nss);
EffBIC = zeros(nsimul,nss);

for r = 1:nss,
   n = samplesizes(r);
   for simul = 1:nsimul
      mu = mumu(1:n,nsimul);
      Y = YY(1:n,simul);
      % full model
      X = [ones(n,1) x1(1:n,simul) x2(1:n,simul)];
      logL = zeros(1,4); ElogL = zeros(1,4); PE = zeros(1,4);
      for m = 1:4,
         Xm = X(1:n,models{m});
         betahatm = (Xm'*Xm)\(Xm'*Y);
         muhatm = Xm*betahatm;
         stdev2hatm = mean((Y-muhatm).^2); % MLE
         logL(m) = -1/2-log(2*pi*stdev2hatm)/2;
         % ElogL optional (not necessary for further calculations)
         ElogL(m) = -sum((mu-muhatm).^2)/(2*n*stdev2hatm)+...
                     stdev^2/(2*stdev2hatm)-log(2*pi*stdev2hatm)/2;
         PE(m) = sum((mu-muhatm).^2)/n;
      end
      AIC = 2*logL-2*p/n;
      BIC = 2*logL-log(n)*p/n;
      [maxPE mstar] = max(PE);
      [maxaic m] = max(AIC); aicmodel(simul,r) = m;
      EffAIC(simul,r) = PE(m)/maxPE;
      [maxbic m] = max(BIC); bicmodel(simul,r) = m;
      EffBIC(simul,r) = PE(m)/maxPE;
   end
end

consistencyAIC = mean(aicmodel==2)
consistencyBIC = mean(bicmodel==2)

tol = 1.e-8;
tol = 0.01;
efficiencyAIC = mean(EffAIC<1+tol)
efficiencyBIC = mean(EffBIC<1+tol)
