
if exist('realrandom') ~= 1, realrandom = false; end
if exist('samplesize') ~= 1, samplesize = 30; end
if exist('fullmodelsize') ~= 1, fullmodelsize = 20; end
knots = [-0.1000 0.1555 0.3143 0.5469 0.6903 0.8730 1.1];
truemodelsize = length(knots)+1;
if exist('makeprint') ~= 1, makeprint = false; end

ForestGreen = [34 139 34]/255;

if realrandom == false, rand('state',0); randn('state',0); end
n = samplesize;
m = fullmodelsize;
k = truemodelsize-1;  % k is # zeros of the polynomial: these k parameters fix
                      % the polynomial up to a constant (ffmax, i.e.,beta_{n-1}
                      % in the assignment)
x = sort(rand(n,1));

nn = 1000;
xx = (0:nn)'/nn;
nn = length(xx);

f = ones(size(x)); ff = ones(size(xx));
for i = 1:k, f = f.*(x-knots(i)); ff = ff.*(xx-knots(i)); end
ffmax = max(abs(ff));
ff = ff/ffmax;
f = f/ffmax;

clearstdev = false;
if exist('stdev') ~= 1, stdev = 0.2; clearstdev = true; end


noise = randn(size(f))*stdev;
y = f+noise;

figure(1)
plot(x,y,'o','markersize',6,'linewidth',3,'color',ForestGreen,...
             'markerfacecolor',ForestGreen)
hold on
plot(xx,ff,'linewidth',2,'color','red')
plot(xx,zeros(size(xx)),'k')
hold off

if makeprint == true,
   set(gcf,'Color', 'none')
   set(gcf,'InvertHardCopy','off')
   set(findobj(gcf,'color','white'),'color','none')

   set(gcf,'position',[0 0 1200 500])
   set(gcf, 'PaperPosition', [0 0 12 5]);

   print -depsc nestedmodel.eps
end


% PE and Cp are defined without studentization or standardization
% i.e.: PE = E(norm(f-fhat)^2)/n
%  and: Cp = SSE/n+2p/n*stdev^2-stdev^2
bias2 = zeros(1,n);
SSE = zeros(1,n);
loss = zeros(1,n);
X = ones(n,1);
I = eye(n);
for p = 1:n-1,
   P = X*((X'*X)\X');
   fhat = P*y;
   Efhat = P*f;
   bias2(p) = f'*(I-P)*f/n;
   SSE(p) = norm(fhat-y)^2;
   loss(p) = norm(fhat-f)^2/n;
   X = [X (x-0.5).^p]; % -0.5 for numerical stability
end
% pp = (0:n-1);
pp = (1:n);
PE = bias2 + pp*stdev^2/n;
Cp = SSE/n + 2*pp/n*stdev^2-stdev^2;

figure(2)
plot(pp,PE,'-o','linewidth',3,'color',ForestGreen,'markersize',8,...
     'markerfacecolor','white')
aa = axis; aa(3) = 0;
hold on
plot(pp,Cp,'-o','linewidth',2,'color','red','markersize',6,...
     'markerfacecolor','white')
hold off
axis(aa)

xticks = get(gca,'XTick');
yticks = get(gca,'YTick');

fontsize = 18;
axis off
aa = axis; aa(2) = 1.1*aa(2); aa(4) = 1.2*aa(4); axis(aa)
drawaxes('linewidth',2,'xticks',xticks,...
         'fontsize',fontsize,'fontweight','b')
Dx = aa(2)-aa(1);
Dy = aa(4)-aa(3);
text(aa(2),-fontsize/150*Dy,'Model size (p)',...
          'HorizontalAlignment','right','fontsize',fontsize,'fontweight','b')
legend('PE','C_p');
set(gca,'fontsize',fontsize,'fontweight','b')


if makeprint == true,
   set(gcf,'Color', 'none')
   set(gcf,'InvertHardCopy','off')
   set(findobj(gcf,'color','white'),'color','none')

   set(gcf,'position',[0 0 1200 500])
   set(gcf, 'PaperPosition', [0 0 12 5]);
   drawaxes('linewidth',2,'xticks',xticks,...
         'fontsize',fontsize,'fontweight','b')

   print -depsc Cpnestedmodel.eps
end

% Now extend the plot of beyond [0,1]
figure(3)
xx = xx*(knots(end)-knots(1)) + knots(1);
[minPE popt] = min(PE);
popt = popt;
Xopt = X(1:n,1:popt);
betahatopt = (Xopt'*Xopt)\(Xopt'*y);
XXopt = ones(nn,1);
for p=1:popt-1, XXopt = [XXopt (xx-0.5).^p]; end
ffhatopt = XXopt*betahatopt;
fhatopt = Xopt*betahatopt;
ff = ones(size(xx))/ffmax;
for i = 1:k, ff = ff.*(xx-knots(i)); end

plot(x,y,'o','markersize',6,'linewidth',3,'color',ForestGreen,...
             'markerfacecolor',ForestGreen)
hold on
plot(xx,ff,'linewidth',3,'color','red')
plot(xx,ffhatopt,'linewidth',2)
plot(xx,zeros(size(xx)),'k')
hold off
axis([knots(1) knots(end) -1.1 1.1])

if makeprint == true,
   set(gcf,'Color', 'none')
   set(gcf,'InvertHardCopy','off')
   set(findobj(gcf,'color','white'),'color','none')

   set(gcf,'position',[0 0 1200 500])
   set(gcf, 'PaperPosition', [0 0 12 5]);

   print -depsc minPEestnestedmodel.eps
   close all
end


if clearstdev == true, clear stdev, end


